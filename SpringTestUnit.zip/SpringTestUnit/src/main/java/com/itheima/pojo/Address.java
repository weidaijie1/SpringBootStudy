package com.itheima.pojo;

public class Address {
    private String province;

    private String distinct;

    private String county;

    /**
     * 此处省略get/set/toString() 方法
     */
}
