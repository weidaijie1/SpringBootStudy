package com.example.logback.mapper;

import com.example.logback.pojo.User;

/**
 * TODO
 *
 * @author liuzebiao
 * @Date 2020-4-10 13:48
 */
public interface UserMapper {
    public User getUserById(int id);
}
