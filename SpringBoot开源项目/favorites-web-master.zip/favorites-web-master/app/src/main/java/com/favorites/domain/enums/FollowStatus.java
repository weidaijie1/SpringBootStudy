package com.favorites.domain.enums;

public enum FollowStatus {

	FOLLOW, UNFOLLOW
}
