package com.example.logback;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CandeleteApplicationTests {

    @Test
    void contextLoads() {
    }

}
